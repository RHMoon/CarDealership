

public class CarIsSoldException extends RuntimeException{
    public CarIsSoldException(String message){
        super(message);
    }
}
