

public class CarIsNotExistException extends RuntimeException{
    public CarIsNotExistException(String message){
        super(message);
    }
}
